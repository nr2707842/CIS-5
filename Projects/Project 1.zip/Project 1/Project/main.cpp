/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 23, 2018, 7:15 PM
 */
//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

 //Global Constants

//Execution Begins Here
const int SIZE = 32;


int ocean[SIZE];

int oceanPos;

 
void shuffle (int deck[], int &position);

void initialize (int deck[]);

void drawcard (int deck[], int &position, int hand[], int &cardsize,
		int &cardsdrawn);

int countrank (int rank, int hand[], int cardsize);

void stealcard (int rank, int from[], int &fromSize, int to[], int &toSize);

void checkset (int rank, int hand[], int &cardsize, int &score,
		char pronoun[]);

void player1turn (int deck[], int player1cards[], int player2cards[],
		   int &position, int &player1cardsize, int &player2cardsize,
		   int &score);

void player2turn (int deck[], int player2cards[], int player1cards[],
		   int &position, int &player2cardsize, int &player1cardsize,
		   int &score);

 
int
main () 
{
  
char yesOrNo = 'y';
  
while (yesOrNo == 'y' || yesOrNo == 'Y')
    
    {
      
	initialize (ocean);
      
 
	shuffle (ocean, oceanPos);
     //Declare Variables
 
int player1cards[50];
      
int player1cardsize = 0;
      
int player2cards[50];
      
int player2cardsize = 0;
      
int cardsdrawn;
      
int player1score = 0;
      
int player2score = 0;
      
int i;
      
 
//Initialize deck
for (i = 0; i < 5; i++)
	
	{
	  
drawcard (ocean, oceanPos, player1cards, player1cardsize,
		     cardsdrawn);
	
}
      
 
for (i = 0; i < 5; i++)
	
	{
	  
drawcard (ocean, oceanPos, player2cards, player2cardsize,
		     cardsdrawn);
	
}
      
 
for (i = 0; i < player1cardsize; i++)
	
	{
	  
cout << player1cards[i] << " ";
	
}
      
 
for (i = 0; i < player2cardsize; i++)
	
	{
	  
cout << player2cards[i] << " ";
	
}
      
 
bool breaking = false;
      
while (oceanPos != 3 && player1cardsize != 0 && player2cardsize != 0
	      && !breaking)
	
	{
	  
	    player1turn (ocean, player1cards, player2cards, oceanPos,
			 player1cardsize, player2cardsize, player1score);
	  
if (player2cardsize == 0 || oceanPos == 31)
	    
	    {
	      
breaking = true;
	      
cout << "Game Over." << endl;
	    
}
	  
	  else
	    
	    {
	      
		player2turn (ocean, player2cards, player1cards, oceanPos,
			     player2cardsize, player1cardsize, player2score);
	    
}
	  
if (player1cardsize == 0 || oceanPos == 31)
	    
	    {
	      
breaking = true;
	      
//Ouput to display Game over, and Final Scores and Play Again
cout << "Game Over." << endl;
cout << "*Final Score*" << endl;
  
cout << "You: " << player1score << endl;
  
cout << "Computer: " << player2score << endl;
  
cout << "Play Again? (y/n) ";
  cin >> yesOrNo;
	    
}
	
}
    
}
  


}


 
void
initialize (int deck[]) 
{
  
int i;
  
for (i = 0; i < SIZE; i++){
deck[i] = 2 + (i % 8);    
}
}
void
shuffle (int deck[], int &position) 
{
int i;
int j;
int temp;
  
for (i = 0; i < SIZE; i++){
j = 1 + rand () % 32;
temp = deck[i];
deck[i] = deck[j];
deck[j] = temp;
}
position = 0;
} 
void
drawcard (int deck[], int &position, int hand[], int &cardsize,
	  int &cardsdrawn){
  
cardsize++;
hand[cardsize - 1] = deck[position];
  
cardsdrawn = hand[cardsize - 1];  
position++;
}
int
countrank (int rank, int hand[], int cardsize){  
int i;
  
int count = 0;
  
for (i = 0; i < cardsize; i++){ 
if (hand[i] == rank){	  
count++;
}
}
return count;}


void
stealcard (int rank, int from[], int &fromSize, int to[], int &toSize){  
int i;
  
for (i = fromSize - 1; i >= 0; i--){    
if (from[i] == rank){  
to[toSize] = rank;
	  
toSize++;
	  
fromSize--;
	  
from[i] = from[fromSize];	
}   
}
}
void
checkset (int rank, int hand[], int &cardsize, int &score, char pronoun[]){
  
int count = countrank (rank, hand, cardsize);
  
int i;
if (count == 4){    
for (i = 0; i < cardsize; i++){
if (hand[i] == rank){
	      
hand[i] = hand[cardsize - 1];
	      
cardsize--;	    
}
}  
score++;
      
cout << pronoun << " scored a set!" << endl;    
}
}
 
void
player1turn (int deck[], int player1cards[], int player2cards[],
	     int &position, int &player1cardsize, int &player2cardsize,
	     int &score){
  
int count = 1;
  
char noun[] = "You";
  
bool breaking = false;
  
while (count > 0 && !breaking){   
int i;
      //output to display what cards there are
cout << "You have: ";
      
for (i = 0; i < player1cardsize; i++){ 
cout << player1cards[i] << " ";
	}
cout << endl;      
 
int guess;
      //Output to display numbers of cards
cout << "You ask if I have any ";
      
cin >> guess;
      
cout << endl;
 
count = countrank (guess, player2cards, player2cardsize);
      
stealcard (guess, player2cards, player2cardsize, player1cards,
		   player1cardsize);
    
if (count > 0){
    
    //output to display what cards there are
cout << "Yes,I have " << count << endl;
	
}
checkset (guess, player1cards, player1cardsize, score, noun); 
if (player2cardsize == 0){ 
breaking = true;	
}   
}
if (count == 0){
      //output to display to go fish
cout << "No, Go Fish!" << endl;
      
int cardsdrawn;
      
drawcard (deck, position, player1cards, player1cardsize, cardsdrawn);
   //output to display what you draw   
cout << "You draw a " << cardsdrawn << "." << endl;
      
cout << endl;
      
checkset (cardsdrawn, player1cards, player1cardsize, score, noun);
      
if (position != 0){
    
    //Output to display whos turn
cout << "My turn!" << endl;
	  
cout << endl;
}
}
} 
void
player2turn (int deck[], int player2cards[], int player1cards[],
	     int &position, int &player2cardsize, int &player1cardsize,
	     int &score){
  
int count = 1;
  
char noun[] = "I";
  
bool breaking = false;
while (count > 0 && !breaking){
int i;      

// Out put to display cards
cout << "You have: ";
for (i = 0; i < player1cardsize; i++){ 
cout << player1cards[i] << " ";}    
cout << endl;
      
int guess = 2 + rand () % 8;
      //Out put to display Question 
cout << "Player 1:ask: Do you have any " << guess << "'s?" << endl;
      
cout << endl;
      
count = countrank (guess, player1cards, player1cardsize);
      
	stealcard ( guess, player1cards, player1cardsize player2cards, player2cardsize );
      
if (count > 0){
    
    //output to display response
cout << "Yes, you have " << count << endl;
	}
checkset (guess, player2cards, player2cardsize, score, noun);
 
if (player1cardsize == 0){
	  
breaking = true;
	
}
    
}
  
if (count == 0){
      //output to display to go fish
cout << "Go Fish" << endl;
      
int cardsdrawn;
      
drawcard (deck, position, player2cards, player2cardsize, cardsdrawn);
 
checkset (cardsdrawn, player1cards, player2cardsize, score, noun);
 
if (position != 0){
	  //output to display turn
cout << "Your turn" << endl;
cout << endl;	
}
}}

//exit
