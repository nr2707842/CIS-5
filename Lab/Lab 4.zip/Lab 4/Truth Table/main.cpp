/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 10, 2018, 7:15 PM
 */

#include <iostream>

using namespace std;

/*Execution begins here*/

int main(int argc, char** argv) {
    //Declare all Variables Here
    bool x,y;
    //Output Table Heading
   cout<<"X Y !X !Y X&&Y X||Y X^Y (X^Y)^Y ";
    cout<<"(X^Y)^X !(X&&Y) !X||!Y !(X||Y) !X&&!Y"<<endl;
    
    //Row 1 output
    x=true;
    y=true;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<" ";
    cout<<(!x?'T':'F')<<" ";
    cout<<(!y?'T':'F')<<" ";
    cout<<(x&&y?'T':'F')<<" ";
    cout<<(x||y?'T':'F')<< " ";
    cout<<(x^y?'T':'F')<< " ";
    cout<<((x^y)^y?'T':'F')<< " ";
    cout<<((x^y)^x?'T':'F')<< " ";
    cout<<(!(x&&y)?'T':'F')<< " ";
    cout<<(!x||!y?'T':'F')<< " ";
    cout<<(!(x||y)?'T':'F')<< " ";
    cout<<(!x&&!y?'T':'F')<< endl;
    
    
    //Row 2 output
    x=true;
    y=false;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<" ";
    cout<<(!x?'T':'F')<<" ";
    cout<<(!y?'T':'F')<<" ";
    cout<<(x&&y?'T':'F')<<" ";
    cout<<(x||y?'T':'F')<<" ";
    cout<<(x^y?'T':'F')<< " ";
    cout<<((x^y)^y?'T':'F')<< " ";
    cout<<((x^y)^x?'T':'F')<< " ";
    cout<<(!(x&&y)?'T':'F')<< " ";
    cout<<(!x||!y?'T':'F')<< " ";
    cout<<(!(x||y)?'T':'F')<< " ";
    cout<<(!x&&!y?'T':'F')<< endl;
    
    //Row 3 output
    x=false;
    y=false;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<" ";
    cout<<(!x?'T':'F')<<" ";
    cout<<(!y?'T':'F')<<" ";
    cout<<(x&&y?'T':'F')<<" ";
    cout<<(x||y?'T':'F')<<" ";
    cout<<(x^y?'T':'F')<< " ";
    cout<<((x^y)^y?'T':'F')<< " ";
    cout<<((x^y)^x?'T':'F')<< " ";
    cout<<(!(x&&y)?'T':'F')<< " ";
    cout<<(!x||!y?'T':'F')<< " ";
    cout<<(!(x||y)?'T':'F')<< " ";
    cout<<(!x&&!y?'T':'F')<< endl;
    
    //Row 4 output
    x=false;
    y=true;
    cout<<(x?'T':'F')<<" ";
    cout<<(y?'T':'F')<<" ";
    cout<<(!x?'T':'F')<<" ";
    cout<<(!y?'T':'F')<<" ";
    cout<<(x&&y?'T':'F')<<" ";
    cout<<(x||y?'T':'F')<<" ";
    cout<<(x^y?'T':'F')<< " ";
    cout<<((x^y)^y?'T':'F')<< " ";
    cout<<((x^y)^x?'T':'F')<< " ";
    cout<<(!(x&&y)?'T':'F')<< " ";
    cout<<(!x||!y?'T':'F')<< " ";
    cout<<(!(x||y)?'T':'F')<< " ";
    cout<<(!x&&!y?'T':'F')<< endl;
    
    return 0;
}