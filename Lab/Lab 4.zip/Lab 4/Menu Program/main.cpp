/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 10, 2018, 8:19 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here */
int main(int argc, char** argv) {

        char choice;//Option 0 to 9 input as a character not a numeric value
    
        
    //Input or initialize values Here
    cout<<"This program illustrates a Menu"<<endl;
    cout<<"Choose the problem you wish to solve"<<endl;
    cout<<"0 -> Gaddis_9thEd_Chap4_Prob1_Minimum Maximum"<<endl;
    cout<<"1 -> Gaddis_9thEd_Chap4_Prob2_Roman Numeral Convertor"<<endl;
    cout<<"2 -> Gaddis_9thEd_Chap4_Prob3_Magic Dates"<<endl;
    cout<<"3 -> Gaddis_9thEd_Chap4_Prob4_Areas of Rectangles"<<endl;
    cout<<"4 -> Gaddis_9thEd_Chap4_Prob5_Body Mass Index"<<endl;
    cout<<"5 -> Gaddis_9thEd_Chap4_Prob6_Mass and Weight"<<endl;
    cout<<"6 -> Gaddis_9thEd_Chap4_Prob7_Time Calculator"<<endl;
    cout<<"7 -> Gaddis_9thEd_Chap4_Prob9_Change for a Dollar Game"<<endl;
    cout<<"8 -> Gaddis_9thEd_Chap4_Prob14_Bank Changes"<<endl;
    cout<<"9 -> Gaddis_9thEd_Chap4_Prob17_Personal Best"<<endl;

    cin>>choice;
    //Process/Calculations Here
    switch(choice){
        case '0':
            cout<<"Calculates Max and Min"<<endl;
            float firstnum,
        secondnum,
        largernum,
        smallernum;
        //output to ask for the two integers
        cout << "Enter two numbers:";
        cin >> firstnum >> secondnum;
        // calculations to see determine which number is large and small
        
        largernum = firstnum >= secondnum? firstnum : secondnum;
        smallernum = firstnum >= secondnum? secondnum : firstnum;
        // output sentence to find out what number is large and which one is small
        cout << "The larger number is " << largernum << ", and the smaller number is " << smallernum << "." << endl;
            break;
        case '1':
            cout<<"Converts the Roman Numerals"<<endl;
            int number;
//output to ask for number 1 to 10
cout << "Enter a number from 1 to 10: ";
cin >> number; 

//Output to display number in roman numeral form 
switch (number)
{
case 1:
cout << "The Roman numeral of " << number << " is ";
cout << "I.";
break;
case 2:
cout << "The Roman numeral of " << number << " is ";
cout << "II.";
break;
case 3:
cout << "The Roman numeral of " << number << " is ";
cout << "III.";
break;
case 4:
cout << "The Roman numeral of " << number << " is ";
cout << "IV.";
break;
case 5:
cout << "The Roman numeral of " << number << " is ";
cout << "V.";
break;
case 6:
cout << "The Roman numeral of " << number << " is ";
cout << "VI.";
break;
case 7:
cout << "The Roman numeral of " << number << " is ";
cout << "VII.";
break;
case 8:
cout << "The Roman numeral of " << number << " is ";
cout << "VIII.";
break;
case 9:
cout << "The Roman numeral of " << number << " is ";
cout << "IX.";
break;
case 10:
cout << "The Roman numeral of " << number << " is ";
cout << "X.";
break;
}
            break;
        case '2':
            cout<<"Calculates which are Magic Dates"<<endl;
            int month,
            day, 
            year;

	//Output to ask user to input date in numeric form 
	cout << "Enter a month, a day, and a two digit year:\n";
	cout << "Enter a month: ";
	cin  >> month;
	cout << "Enter a day: ";
	cin  >> day;
	cout << "Enter a year: ";
	cin  >> year;

	// Calculation and output to determine if date is magic or not
	if (year == month * day)
		cout << "This date is magic !\n";
	else
		cout << "This date is not magic. . . \n";
            break;
             case '3':
            cout<<"Calculates the Area of a rectangle"<<endl;
             double
    lengthone,
    lengthtwo,
            widthone,
            widthtwo,
            areaone,
            areatwo;
    //output asking for the length and width of the rectangles
    cout<<"Enter the length for the first rectangle: ";
    cin>>lengthone;
    cout<<"Enter the width for the first rectangle: ";
    cin>>widthone;
    cout<<"Enter the length of the second rectangle: ";
    cin>>lengthtwo;
    cout<<"Enter the width of the second rectangle: ";
    cin>>widthtwo;
    //formula to calculate area of rectangle
    areaone= lengthone*widthone;
    areatwo=lengthtwo*widthtwo;
    //output to calculate which rectangle is greater or if both are the same
    if(areaone > areatwo)
        cout<<"The area of the first rectangle is greater than the area of the second.";
    else
    
        if (areaone==areatwo)
            cout<<"The area of both rectangles are the same.";
            break;
             case '4':
            cout<<"Calculates BMI"<<endl;
           
    double weight,
            height,
            bmi;
    
    cout<<"Enter your weight: ";
    cin>>weight;
    cout<<"Enter your height: ";
    cin>>height;
    //bmi calculation to determine if overweight, underweight or optimal
    bmi=(weight*703) /(height*height);
    
    //output to determine what users bmi is
    if(bmi<18.5)
        cout<<"You are underweight.";
    if(bmi>18.5 && bmi<25)
        cout<<"You are optimal.";
    if(bmi>25)
        cout<<"You are overweight.";
            break;
            
             case '5':
            cout<<"Calculates Mass and Weight"<<endl;
         double mass;
    
    cout<<"Enter the mass of an object:";
    cin>>mass;
    //formula for weight
    weight=mass*9.8;
   
   //calculation and output for mass that is too heavy
 cout<<"This object is "<< weight <<" newtons.";
    if(mass>=1000)
 
 cout<<"This object is too heavy."<<mass<<endl;
 //calculation and output if mass is too light
 else if(mass<=10)
 
 cout<<"This object is too light."<<mass<<endl;
 
            break;
             case '6':
            cout<<"Calculates Time"<<endl;
double seconds, 
       hour;

 hour = 3600;
 day = 86400;
//output to enter the number of seconds
 cout << "Enter the number of seconds: ";
 cin >> seconds;
//calculation and output from seconds to days
 if(seconds >= 86400)
 cout << "The seconds you entered: " << seconds/86400 << " days \n\n";
 else
//calculation and output from seconds to hours
 if(seconds >= 3600)     
 cout << "The seconds you entered: " << seconds/3600 << " hours \n\n";
 else
  //calculation and out put from seconds to minutes
 if(seconds >= 60)
 cout << "The seconds you entered: " << seconds/60 << " minutes \n\n";
 else
 
 if(seconds < 60 && seconds > 0)
 cout << "The seconds you entered: " << seconds << " seconds \n\n";
            break;
             case '7':
            cout<<"Calculates the amount of change"<<endl;
                  double pennies,
            nickels,
            dimes,
            quarters,
            totalamount;
    
    //output to ask for number of pennies, nickels, dimes and quarters
    cout<<"Enter number of pennies: ";
    cin>>pennies;
    cout<<"Enter the number of nickels: ";
    cin>>nickels;
    cout<<"Enter the number of dimes: ";
    cin>>dimes;
    cout<<"Enter the number of quarters: ";
    cin>>quarters;
    
    //calculation to determine how much total will be 
    totalamount=(pennies*0.01) + (nickels*0.05)+(dimes*0.10)+(quarters*0.25);
   //output for entering in one dollar
    if(totalamount==1.00)
        cout<<"You've entered in one dollar!";
    else
        //output for entering less than one dollar
        if (totalamount<1.00 && totalamount>0)
              cout<<"You've entered in less that one dollar.";
        else
            //output for entering more than one dollar
            if(totalamount>1.00)
                cout<<"You've entered more than one dollar.";
            break;
             case '8':
            cout<<"Creates the amount of Bank Charges"<<endl;
                double
    
    begbalance,
            fee1,
            fee2,
            totalfee,
    checks;
    cout<<"Enter the beginning balance: $ ";
    cin>>begbalance;
    
    if(begbalance<0)
        
        cout<<"Your account is overdrawn.";
                
    else
        cout<<"Enter the number of checks written: ";
    cin>>checks;
    
    if(begbalance<400)
        fee1=15.00;
    else
        fee1=0.00;
    //calculation for check fee
     if(checks >= 0 && checks < 20)
 fee2 = checks * 0.10;
 if(checks >= 20 && checks <= 39)
 fee2 = checks * 0.08;
 if(checks >= 40 && checks <= 59)
 fee2 = checks * 0.06;
 if(checks >= 60)
 fee2= checks * 0.04;
 if(checks < 0)

     totalfee=fee1+fee2;
    //Output displaying fees    
    cout<<"Low Balance Fee: $"<<fee1<<endl;
    cout<<"Check Fees: $"<<fee2<<endl;
    cout<<"Total Monthly fees $"<<totalfee<<endl;
            break;
             case '9':
            cout<<"Calculates the"<<endl;
                int books,
            points;
    //output to calculate number of points given
    cout<<"Enter the number of books purchased this month: ";
    cin>>books;
    
    if(books==0){
        points=0;
    
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==1){
        points=5;
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==2){
        
        points=15;
    
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==3){
        
        points=30;
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==4){
        
        points=60;
        cout<<"You've earned: "<<points<<" points.";
    }          
            break;
         
        default:
            cout<<"Having trouble following instructions?"<<endl;
    }
    
    //Exit Stage Right
    return 0;
}
  

