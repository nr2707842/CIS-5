/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 7:54 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//declare variables
    double
    lengthone,
    lengthtwo,
            widthone,
            widthtwo,
            areaone,
            areatwo;
    //output asking for the length and width of the rectangles
    cout<<"Enter the length for the first rectangle: ";
    cin>>lengthone;
    cout<<"Enter the width for the first rectangle: ";
    cin>>widthone;
    cout<<"Enter the length of the second rectangle: ";
    cin>>lengthtwo;
    cout<<"Enter the width of the second rectangle: ";
    cin>>widthtwo;
    
    //formula to calculate area of rectangle
    areaone= lengthone*widthone;
    areatwo=lengthtwo*widthtwo;
    
    //output to calculate which rectangle is greater or if both are the same
    if(areaone > areatwo)
        cout<<"The area of the first rectangle is greater than the area of the second.";
    else
    
    if (areaone==areatwo)
        cout<<"The area of both rectangles are the same.";
//Exit
return 0;
}

