/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 5:29 PM
 */

#include <iostream>

using namespace std;
//execution begins here
int main(){
    //declare variables
  float firstnum,
        secondnum,
        largernum,  
        smallernum;
  
        //output to ask for the two integers
        cout << "Enter two numbers:";
        cin >> firstnum >> secondnum;
        
        // calculations to see determine which number is large and small
        largernum = firstnum >= secondnum? firstnum : secondnum;
        smallernum = firstnum >= secondnum? secondnum : firstnum;
        
        // output sentence to find out what number is large and which one is small
        cout << "The larger number is " << largernum << ", and the smaller number is " << smallernum << "." << endl;
        
        return 0;
}