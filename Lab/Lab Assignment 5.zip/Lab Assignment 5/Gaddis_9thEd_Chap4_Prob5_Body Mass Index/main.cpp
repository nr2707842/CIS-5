/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 5:58 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here */
int main(int argc, char** argv) {

    double weight,
           height,
           bmi;
    
    cout<<"Enter your weight: ";
    cin>>weight;
    cout<<"Enter your height: ";
    cin>>height;
    
    //bmi calculation to determine if overweight, underweight or optimal
    bmi=(weight*703) /(height*height);
    
    //output to determine what users bmi is
    if(bmi<18.5)
        cout<<"You are underweight.";
    if(bmi>18.5 && bmi<25)
        cout<<"You are optimal.";
    if(bmi>25)
        cout<<"You are overweight.";
    
    //end of program
    return 0;
}

