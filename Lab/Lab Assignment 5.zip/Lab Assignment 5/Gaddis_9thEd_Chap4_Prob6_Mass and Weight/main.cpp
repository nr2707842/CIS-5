/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 8:08 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
    
//Declare variables
    double
    mass,
    weight;
    
    cout<<"Enter the mass of an object:";
    cin>>mass;
    
    //formula for weight
    weight=mass*9.8;
   
   //calculation and output for mass that is too heavy
    cout<<"This object is "<< weight <<" newtons.";
    
    if(mass>=1000)
    cout<<"This object is too heavy."<<mass<<endl;
   //calculation and output if mass is too light
    else if(mass<=10)
    cout<<"This object is too light."<<mass<<endl;
 
    //program end
    return 0;
}

