
/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 9:04 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {

    //Declare variables
    double begbalance,
           fee1,
           fee2,
           totalfee,
           checks;
    
           cout<<"Enter the beginning balance: $ ";
           cin>>begbalance;
        
    //if formula to determine how much the balance is
    if(begbalance<0)
        cout<<"Your account is overdrawn.";
                
    else
        cout<<"Enter the number of checks written: ";
        cin>>checks;
    
    if(begbalance<400)
        fee1=15.00;
    else
        fee1=0.00;
    
    //calculation for check fee
     if(checks >= 0 && checks < 20)
        fee2 = checks * 0.10;
        if(checks >= 20 && checks <= 39)
        fee2 = checks * 0.08;
        if(checks >= 40 && checks <= 59)
        fee2 = checks * 0.06;
        if(checks >= 60)
        fee2= checks * 0.04;
        if(checks < 0)
        totalfee=fee1+fee2;
    
    //Output displaying fees    
    cout<<"Low Balance Fee: $"<<fee1<<endl;
    cout<<"Check Fees: $"<<fee2<<endl;
    cout<<"Total Monthly fees $"<<totalfee<<endl;
    
    //end of program
    return 0;
}

