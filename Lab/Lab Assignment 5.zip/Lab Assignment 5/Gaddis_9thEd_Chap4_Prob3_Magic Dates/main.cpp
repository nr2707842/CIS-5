/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 5:47 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
    //Declare variables
	int month,
            day, 
            year;

	//Output to ask user to input date in numeric form 
	cout << "Enter a month, a day, and a two digit year:\n";
	cout << "Enter a month: ";
	cin  >> month;
	cout << "Enter a day: ";
	cin  >> day;
	cout << "Enter a year: ";
	cin  >> year;

	// Calculation and output to determine if date is magic or not
	if (year == month * day)
		cout << "This date is magic !\n";
	else
		cout << "This date is not magic. . . \n";
	return 0;
}


