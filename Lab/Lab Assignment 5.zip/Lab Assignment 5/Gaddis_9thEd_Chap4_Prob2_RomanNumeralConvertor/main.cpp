/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 7:26 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {

 int number;
//output to ask for number 1 to 10
    cout << "Enter a number from 1 to 10: ";
    cin >> number; 

//Output to display number in roman numeral form 
switch (number)
{
case 1:
    cout << "The Roman numeral of " << number << " is ";
    cout << "I.";
    break;
case 2:
    cout << "The Roman numeral of " << number << " is ";
    cout << "II.";
    break;
case 3:
    cout << "The Roman numeral of " << number << " is ";
    cout << "III.";
    break;
case 4:
    cout << "The Roman numeral of " << number << " is ";
    cout << "IV.";
    break;
case 5:
    cout << "The Roman numeral of " << number << " is ";
    cout << "V.";
    break;
case 6:
    cout << "The Roman numeral of " << number << " is ";
    cout << "VI.";
    break;
case 7:
    cout << "The Roman numeral of " << number << " is ";
    cout << "VII.";
    break;
case 8:
    cout << "The Roman numeral of " << number << " is ";
    cout << "VIII.";
    break;
case 9:
    cout << "The Roman numeral of " << number << " is ";
    cout << "IX.";
    break;
case 10:
    cout << "The Roman numeral of " << number << " is ";
    cout << "X.";
    break;
}
//end of program
return 0;
}


