/*File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 11, 2018, 9:42 PM
 */

#include <iostream>
using namespace std;

const char  percent=100;  //Percent conversion
const float billion=1e9f; //Billion conversion
const float trillion=1e12f;//Trillion conversion

int main(int argc, char** argv) {
    float   milBdgt,
            fedBdgt,
            milPrcnt;
    
    
    fedBdgt=4.1e12f;
    milBdgt=7.0e11f;
    
    milPrcnt=milBdgt/fedBdgt*percent;
    
    cout<<"The Federal Budget =  $"<<fedBdgt/trillion<<" Trillion"<<endl;
    cout<<"The Military Budget = $"<<milBdgt/billion<<" Billion"<<endl;
    cout<<"Percentage Military Budget = "<<milPrcnt<<"%"<<endl;
    
    return 0;
}
