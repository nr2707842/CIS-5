/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 10:49 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {

    	int Class;
	string Name,
               Front,
               End;
        //Output to ask for the number of students  

    cout << "How many students are in the class? ";
            cin  >> 
            Class;

while (Class < 1 || Class > 25){
    cout << "\nError!\nThe number of students in the class must be greater than 25 "
	<< "How many students are in the class? ";
    cin  >> Class;}

    cout << "Enter the first name of the student: ";
    cin  >> Name;
    Front = End = Name;
for (int Count = 1; Count < Class; Count++){
    cout << "Enter the first name of the next student: ";
    cin  >> Name;

if (Name > End)
    End = Name;
if (Name < Front)
    Front = Name;}
//Output of order
    cout << endl << Front << " is at the front of the line and\n"
    << End << " is at the end of the line.\n";
//Exit
return 0;
}


