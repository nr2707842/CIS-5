/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 10:14 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
    //Declare Variables
	int days,				 
            sizeofpopulation;	
        
	double	increase;		

//Output to display the commands for user
	cout << "What is the number of organisms? ";
	cin  >> sizeofpopulation;
	cout << "What is the average population increase?\n";
	cin  >> increase;
	cout << "Enter the number of growth: ";
	cin  >> days;

	// Input Validation
	while (sizeofpopulation < 2 || increase < 0 || days < 1)
	{
	if (sizeofpopulation < 2){
            cout << "Error!\nStarting size of population "
            << "must be greater than two!\n";
            cout << "What is the starting number of organisms? ";
            cin  >> sizeofpopulation;
		}
        else if (increase < 0){
			cout << "Error!\nAverage daily population "
				 << "increase must be greater than 0.\n";
			cout << "What is the average daily population increase? \n"
				 << "(as a percentage of current population)? ";
			cin  >> increase;}
	else if (days < 1){ 
			cout << "Error!\nNumber of days must be greater than 0.\n-5";
			cout << "Enter the number of days of growth: ";
			cin  >> days;}
	}
	cout << "\nTable displaying population increase over " << days << " days.\n"
		 << "      Day              Size of population\n";

//calculation in order to determine the number of pop
	for (int X = 1; X <= days; X++){
                cout << "      " <<X << "                      "<< sizeofpopulation << endl; 
		sizeofpopulation *= (1 + (increase / 100));}
        //exit
	return 0;
}


