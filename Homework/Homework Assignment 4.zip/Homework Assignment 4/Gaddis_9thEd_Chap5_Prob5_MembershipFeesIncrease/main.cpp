/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 9:00 PM
 */

#include <iostream>

using namespace std;

/*Executions Begins Here*/
int main(int argc, char** argv) {
//Declare variables
    const double rate = 0.04,
    currentcharge = 2500.0;
	int year;
	double yrRate;
//Output to display table and rates and years
	cout << "Country club projected rates\n"
		 << "  for the next six years\n"
		 << "      Year       Rate\n";

	for(year = 1; year <= 6; year++)
	{
	yrRate = currentcharge * (1 + year * rate);
	cout << "       " << year << "         " << yrRate << endl;
	}
	cout << endl;
        
        //exist
return 0;
}