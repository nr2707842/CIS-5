/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 11:06 PM
 */

#include <iostream>

using namespace std;

/* Execution Begins Here*/
int main(int argc, char** argv) {

    int speed,
        hours,
        distance=0;
    
    cout<<"What is the speed of the car in mph?";
    cin>>speed;
    cout<<"How many hours have you traveled?";
    cin>>hours;
    
   //Calculation to determine mph 
    
    if(speed>=0 && hours>=1){
        cout<<"Hour    Distance Traveled\n";
                
                for(int x=1; x<=hours; x++){
                    
                    distance+=speed;
                    cout<<right<<x<<"   "<<distance<<endl;
                }
    }
    
    //Exit
    return 0;
}

