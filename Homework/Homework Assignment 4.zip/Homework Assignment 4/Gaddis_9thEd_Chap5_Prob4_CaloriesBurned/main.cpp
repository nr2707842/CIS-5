/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 10:07 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//Declare Variables
const double calspermin= 3.6;

int Min,
    Burnt = 0; 	
//Output of table
    cout << "\nTable displaying number of calories burnt on a treadmill.\n"
		 << "\n   Minutes Ran      Calories Burnt\n";
//calculation of how many calories were burnt 
for(Min = 10; Min <= 30; Min += 5){
    Burnt = Min * calspermin;
    cout << "        "<< Min << "               " << Burnt << endl; }
    cout << endl;
    //exit
return 0;
}


