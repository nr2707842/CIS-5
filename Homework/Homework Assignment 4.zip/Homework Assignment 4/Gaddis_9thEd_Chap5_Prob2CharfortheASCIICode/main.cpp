/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 10:02 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//Decalre Variables
    	char letter;
//Output to display code
	cout << " Characters for ASCII codes 0 through 127.\n";

	letter = 0;
//output for the code order
for(int count = 0; count <= 127; count++){
if (count % 16 ==0)
    cout << endl; 
    cout << letter << "  ";
    letter++;}
        //exit
	return 0;
}

