/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 8:07 PM
 */

#include <iostream>
using namespace std;

/*Execution Begins here*/
int main(int argc, char** argv) {
    //double variable
    const double MIL_PER_YEAR = 1.5;
    
    // Output to determine the amount the ocean will grow
    cout << "The ocean's level will grow " << MIL_PER_YEAR * 25;
    cout << " millimeters after 25 years." << endl;
    cout << endl;
    
//exit
return 0;
}