/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 10:33 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//input variables
    	float budgetmon;		
	float expensemon;		
	float total;			
 	int count; 
 
	expensemon = 0;
	budgetmon = 0;
 
//Output to display commands
	cout << "Enter the amount of money you budgeted: " << endl;
	cin >> budgetmon;
 for (count = 1; count <= 3; count ++ ){
	cout << "Enter all of your expenses for the month: " << endl;
	expensemon += expensemon;

        cin >> expensemon;
	}
 
//Formula to calculate total
	total = budgetmon - expensemon;
 
//Output of money after expenses
	cout << "Your total after expenses: $" << total << endl;
 
if (total > 0)
	cout << "Your expenses are under the budget!";
else
	cout << "Your expenses are over the budget!";
 //exit
return 0;
}
