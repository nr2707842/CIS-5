/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 7:54 PM
 */

#include <cmath>
#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

int main(){
    //declare variables
    int num, 
        maxnum,
        total;
    //Output to ask for integer
    cout << "Enter an integer number: ";
    cin >> num;
    //Calculation to determine the sum of the integers
    while (num < 0){
       cout << "Please enter a positive integer: " << endl;
       cin >> num;}
    for (maxnum = 1; maxnum <= num; maxnum++){
        total += maxnum;}
    //Output of the sum
cout << "The sum of all integer numbers from 1 to ";
    cout << num << " is: " << total << endl;
    cin.ignore();
    cin.get();
    //exit
    return 0;
}