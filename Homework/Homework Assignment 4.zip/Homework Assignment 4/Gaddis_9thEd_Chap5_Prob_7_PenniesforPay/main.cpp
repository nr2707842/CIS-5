/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 18, 2018, 9:19 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//declare variables 
    
    int penny = 1,      

        workedDays,   

        days = 1;    

    double total;      

    
    cout << "Enter the number of days worked: ";     

    cin >> workedDays;

    //Validation of input 

    while (workedDays < 1){

        cout << "The number of days you enter is not valid!\n";
    cout << "Reenter a number greater than zero";
cin >> workedDays;}

    //Display table
    cout << "Days\tSalary\n";

    while (days <= workedDays){
          cout << days << "\t" << (penny * 2)  << endl;
          days++;
    }
    
    //Exit
    return 0;

}

