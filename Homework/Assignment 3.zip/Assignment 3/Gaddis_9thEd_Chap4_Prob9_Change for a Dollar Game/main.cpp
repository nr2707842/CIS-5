/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 6:33 PM
 */

#include <iostream>

using namespace std;

/*Execution Begins Here*/
int main(int argc, char** argv) {
//declare variables
    double pennies,
            nickels,
            dimes,
            quarters,
            totalamount;
    
    //output to ask for number of pennies, nickels, dimes and quarters
    cout<<"Enter number of pennies: ";
    cin>>pennies;
    cout<<"Enter the number of nickels: ";
    cin>>nickels;
    cout<<"Enter the number of dimes: ";
    cin>>dimes;
    cout<<"Enter the number of quarters: ";
    cin>>quarters;
    
    //calculation to determine how much total will be 
    totalamount=(pennies*0.01) + (nickels*0.05)+(dimes*0.10)+(quarters*0.25);
   //output for entering in one dollar
    if(totalamount==1.00)
        cout<<"You've entered in one dollar!";
    else
        //output for entering less than one dollar
        if (totalamount<1.00 && totalamount>0)
              cout<<"You've entered in less that one dollar.";
        else
            //output for entering more than one dollar
            if(totalamount>1.00)
                cout<<"You've entered more than one dollar.";
      //end of program
    return 0;
}

