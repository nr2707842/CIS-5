/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 6:14 PM
 */
#include <iostream>

using namespace std;

//Execution Begins Here
int main(int argc, char** argv) {
//declare variables
double seconds, hour, day;
 hour = 3600;
 day = 86400;
//output to enter the number of seconds
 cout << "Enter the number of seconds: ";
 cin >> seconds;
//calculation and output from seconds to days
 if(seconds >= 86400)
 cout << "The seconds you entered: " << seconds/86400 << " days \n\n";
 else
//calculation and output from seconds to hours
 if(seconds >= 3600)
 cout << "The seconds you entered: " << seconds/3600 << " hours \n\n";
 else
  //calculation and out put from seconds to minutes
 if(seconds >= 60)
 cout << "The seconds you entered: " << seconds/60 << " minutes \n\n";
 else
 
 if(seconds < 60 && seconds > 0)
 cout << "The seconds you entered: " << seconds << " seconds \n\n";
 
 return 0;
}

