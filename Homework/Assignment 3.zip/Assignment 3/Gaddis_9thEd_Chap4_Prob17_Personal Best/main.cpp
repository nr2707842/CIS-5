/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on October 4, 2018, 8:46 PM
 */

#include <iostream>

using namespace std;

/*Execution begins here*/
 
int main(int argc, char** argv) {
//Declare variables
    int books,
            points;
    //output to calculate number of points given
    cout<<"Enter the number of books purchased this month: ";
    cin>>books;
    
    if(books==0){
        points=0;
    
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==1){
        points=5;
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==2){
        
        points=15;
    
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==3){
        
        points=30;
    cout<<"You've earned: "<<points<<" points.";
    }
    if(books==4){
        
        points=60;
        cout<<"You've earned: "<<points<<" points.";
    }          
    //end of program
    return 0;
}

