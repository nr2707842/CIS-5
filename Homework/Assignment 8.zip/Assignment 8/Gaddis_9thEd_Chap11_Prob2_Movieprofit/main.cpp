/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on December 7, 2018, 9:15 PM
 */

#include <iostream>
#include <string>

using namespace std;

struct MovieData {
string Title;
string Director;
unsigned short YearReleased;
unsigned short RunningTime;
unsigned short FirstYearProfit;
};

void print(MovieData &md) {
cout << "Title: " << md.Title << endl
<< "Director: " << md.Director << endl
<< "Year Released: " << md.YearReleased << endl
<< "Running Time: " << md.RunningTime << " minutes" << endl;
<< "FirstYearProfit: " << md.FirstYearProfit<< endl;

}
// Execution Begins Here
int main(int argc, char** argv) {

MovieData 
movFirst, 
movSecond;

//output to display both movies data
movFirst.Title = "Despicable Me";
movFirst.Director = "Pierre Coffin,Chris Renaud";
movFirst.YearReleased = 2010;
movFirst.RunningTime = 95;
movFirst.FirstYearProfit=143,005,856;
movSecond.Title = "The Meg";
movSecond.Director = "John Turtleaub";
movSecond.YearReleased = 2018;
movSecond.RunningTime = 112;
movSecond.FirstYearProfit=305,062,360;

cout << endl;
print(movFirst);
cout << endl;
print(movSecond);
cout << endl;

return 0;
}