/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on December 3, 2018, 10:01 PM
 */

#include <iostream>

using namespace std;

//Execution Begins Here
int* doit(const int num)
{
    int* addr = new int[num];  
   return addr;
}
