/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on December 3, 2018, 8:49 PM
 */

#include <iostream>

using namespace std;
//Function Prototypes

int searchList (const int [], int, int);
const int SIZE =10;
//Execution Begins Here
int main(int argc, char** argv) {

    //Declare Variables
    	int tickets [SIZE]= {
		13579, 26791, 26792, 33445, 55555,
		62483, 77777, 79422, 85647, 93121 };
	int winningnumber;
	int results;

        //Ouput to display command
	cout << "\nPlease enter this week's winning 5-digit number: ";
	cin >> winningnumber;

	results=searchList (tickets, SIZE, winningnumber);

        //Loop to display if a ticket is winner or not
	if (results==-1)
		cout << "None of your tickets is a winner.\n";
	else
		cout << "Your ticket is a winner this week." << endl;
	return 0;
}

int searchList (const int list[], int numElems, int value)
{
	int index=0;
	int position=-1;
	bool found=false;

	while (index < numElems && !found)
	{
		if (list[index]==value)
		{
			found=true;
			position=index;
		}
		index++;
	}
        
        //exit here
	return position;
}
 

