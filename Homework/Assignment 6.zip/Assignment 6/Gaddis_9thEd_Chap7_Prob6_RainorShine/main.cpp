/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 25, 2018, 8:26 PM
 */

//System Libraries
#include <cstdlib>
using namespace std;

// Execution Begins Here
int main(int argc, char** argv) {
//Declare Variables
	int month = 3,					
	    day = 30;				
	char weather[month][day];			

	int Sun,						
		Rain,						
		Cloudy,						
		totSun = 0,				
		totRain = 0,				
		totCloudy = 0,			
		lrgstRain = 0;				
		
	ifstream Read;				
	Read.open("RainOrShine.dat");	
	if (!Read)
		cout << "Error opening data file.";
	else
	{	// Read weather data in from file
		for (int row = 0; row < month; row++)
		{
			for (int col = 0; col < day; col++)
			{
				Read >> weather[row][col];
			}
		}
	}
	Read.close();					

	
	cout << "Three-month weather report";
	for (int row = 0; row < month; row++)
	{
		Sun = Rain = Cloudy = 0;
		for (int col = 0; col < day; col++)
		{	// Calculate monthly numbers
			switch (weather[row][col])
			{
				case 'S' : Sun++;
							break;
				case 'R' : Rain++;
							break;
				case 'C' : Cloudy++;
							break;
			}
		}

		//Output to display the monthly numbers
		cout << "\nFor the month of ";
		if (row == 0)
			cout << "June.\n";
		else if (row == 1)
			cout << "July.\n";
		else if (row == 2)
			cout << "August.\n";

		cout << "Rainy : " << Rain << endl
			 << "Sunny : " << Sun  << endl
			 << "Cloudy: " << Cloudy << endl;

		//formula to calculate the months
		totSun += Sun;
		totRain += Rain;
		totCloudy += Cloudy;

		//loop to calculate days with rainy days
		if(lrgstRain > Rain)
			lrgstRain = row;
	}

	// output to display monthly totals
	cout << "Three-month period\n"
		 << "Rainy : " << totRain << endl
		 << "Sunny : " << totSun  << endl
		 << "Cloudy: " << totCloudy << endl;

	// output to display the month with max numbers
	cout << "Month with largest number: ";
		if (lrgstRain == 0)
			cout << "June.\n\n";
		else if (lrgstRain == 1)
			cout << "July.\n\n";
		else if (lrgstRain == 2)
			cout << "August.\n\n";

                //Exit Here
	return 0;
}