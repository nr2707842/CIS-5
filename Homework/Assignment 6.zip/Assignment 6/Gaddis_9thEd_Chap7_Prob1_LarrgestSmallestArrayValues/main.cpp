/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 25, 2018, 7:20 PM
 */

//System Libraries
#include <iostream>
using namespace std;

// Execution Begins Here
int main(int argc, char** argv) {
//Declare Variables
int min,max;
const int num = 10;
//Displays the "enter number:" 10 Times
int a[num]; 
cout<<"Enter 10 numbers:"; //prompts user for 10 values.
for(int i=0;i<10;i++)
{
    //Diplays Question
cout<< "\nEnter number: ";
//Puts the numbers in the array to calculate the min and ma
cin>> a[i];
}

min=a[0];
max=a[0];
for(int i=1;i<10;i++)
	{
		if(min>a[i])
		{
			min=a[i];
		}
		else if(max<a[i])
		{
			max = a[i];
		}
	}

//Displays the largest number and smallest number
cout<<"LARGEST NUMBER: "<< max << endl;
cout<<"SMALLEST NUMBER: "<< min << endl;

return 0;

}