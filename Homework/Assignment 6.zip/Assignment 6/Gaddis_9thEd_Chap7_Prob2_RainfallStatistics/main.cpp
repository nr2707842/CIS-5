/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 25, 2018, 7:29 PM
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;


int main(int argc, char** argv) {
//Declare Variables
    
const int year = 12;

double highest, lowest, getAverage;
double total = 0;
double rainfall[year];
//Output to ask for the rainfall for these monnths
string months[year] = { "January", "February", "March", "April","May", "June", "July", "August", "September","October", "November", "December" };

cout << "Enter the rainfall in inches: " << endl;

//loop to calculate number of rainfall
for ( int month = 0; month < year; month++ )
{
cout << "\nThe rainfall for the month of " << months[month] << ": ";
cin >> rainfall[month];
total += rainfall[month];

//loop to validate the input
while (rainfall[month] < 0)
{
cout << "\nRainfall must be zero or more.";
cout << "\nPlease enter positive amount for " << months[month] << " again: ";
cin >> rainfall[month];
total += rainfall[month];
}
}

cout << "\nThe total rainfall amount is: \t\t" << total << endl;

getAverage = total / year;
cout << "\nThe average rainfall amount is: \t" << getAverage << endl;

// out put to get the highest and lowest amount in rainfall
string maxMonth, minMonth;

for ( int month = 0; month < year; month++ )
{
highest = rainfall[0];
for ( int count = 0; count < year; count++ )
{
if ( rainfall[count] > highest )
{
highest = rainfall[count];
maxMonth = months[count];
}
}
lowest = rainfall[0];
for ( int count = 0; count < year; count++ )
{
if ( rainfall[count] < lowest )
{
lowest = rainfall[count];
minMonth = months[count];
}
}
}
//Output to display the max and min rainfall
cout << "\n" << maxMonth << " was the month with the highest rainfall of " << highest << " inches." << endl;
cout << "\n" << minMonth << " was the month with the lowest rainfall of " << lowest << " inches." << endl;

//Exit here
return 0;
}
