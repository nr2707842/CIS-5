/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 25, 2018, 7:56 PM
 */

//System Libraries
#include <iostream>

using namespace std;

// Execution Begins here
int main(int argc, char** argv) {
//Declare Variables
    
	const int MONKEYS = 3;
	const int DAYS = 7;
	int food[MONKEYS][DAYS];
	int maximum = food[0][0];
	int minimum = food[0][0];
	float total = 0.0f;
	float average = 0.0f;

        //output to input the amount of food

	cout << "Enter the amount of food for each monkey: " << endl;

	//loop to get the sum of user
	for (int monk = 0; monk < MONKEYS; monk++)
	{
		for (int day = 0; day < DAYS; day++)
		{
			cout << "Monkey " << (monk + 1) << ", day " << (day + 1) << ": ";
			cin >> food[monk][day];

			total += food[monk][day];

		}
		cout << endl;
	}
	//formula to calculate the average
	average = total / (MONKEYS * DAYS);

	 //loop to get the num of most eaten
	for (int monk = 0; monk < MONKEYS; monk++)
	{
		for (int day = 0; day < DAYS; day++)
		{
			if (food[monk][day] > maximum)
				maximum = food[monk][day];
		}

	}

	//loop to get the num of least eaten
	minimum = maximum; // <- This line is important!
	for (int monk = 0; monk < MONKEYS; monk++)
	{
		for (int day = 0; day < DAYS; day++)
		{
			if (food[monk][day] < minimum)
				minimum = food[monk][day];
		}

	}
        
        //output to display the amount of food eaten
	cout << "Total amount of food: " << total << endl;
	cout << "Average amount consumed:" << average << endl;
	cout << "Most Eaten:" << maximum << endl;
	cout << "Least Eaten:" << minimum << endl;

	
	return 0;
}

