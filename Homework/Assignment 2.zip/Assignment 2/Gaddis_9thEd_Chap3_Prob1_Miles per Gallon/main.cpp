/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 7:00 PM
 */

#include <iostream>
using namespace std;

/* Calculating the miles per Gallon*/
int main(int argc, char** argv) {
//Declare variables
    double capacity,
            miles,
            average;
    //Display Outputs
    cout<< "Enter the number of size of the tank (gallons):"; cin>> capacity;
    cout<<"Enter the number of miles per tank of gas: "; cin>> miles;
    average=miles/capacity;
    cout<< "The car's MPG is:" <<average << endl << endl;
    
    system("pause");
   //Exit
    return 0;
}

