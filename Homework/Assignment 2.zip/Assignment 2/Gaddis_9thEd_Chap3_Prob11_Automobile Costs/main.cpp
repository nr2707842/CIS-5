/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 9:02 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;
int main(int argc, char** argv) {
    //Declare Variables
double loanpayment, 
       insurance, 
        gas, 
        oil, 
        tires, 
        maintenance, 
        total;

double monthlycost;
 //output 
cout << setprecision(2) << fixed << showpoint;
cout << "Enter monthly cost for loan payment: " << endl;;
cin >> loanpayment;
cout << "Enter monthly cost for insurance: " << endl;
cin >> insurance;
cout << "Enter monthly cost for gas: " << endl;
cin >> gas;
cout << "Enter monthly cost for oil: " << endl;
cin >> oil;
cout << "Enter monthly cost for tires: " << endl;
cin >> tires;
cout << "Enter monthly cost for maintenance: " << endl;
cin >> maintenance;
 //process input to output 
total = loanpayment + insurance + gas + oil + tires + maintenance;
  //output
cout << "Monthly Cost: $" << total << endl;
cout << "Yearly Cost: $" << (total * 12) << endl;
 return 0;
}