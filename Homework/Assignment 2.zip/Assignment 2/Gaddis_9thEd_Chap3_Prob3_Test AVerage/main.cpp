/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 7:42 PM
 */

#include <iostream>
#include<iomanip>
using namespace std;

/* Calculating Test Average*/
int main(int argc, char** argv) {

    //Variables
    
    double score01,
            score02,
            score03,
            score04,
            score05,
            average;
    
    //Display outputs
    cout<< "Enter score 1: ";
    cin>> score01;
    cout<< "Enter score 2: ";
    cin>> score02;
    cout<<"Enter score 3: ";
    cin>> score03;
    cout<< "Enter score 4: ";
    cin>> score04;
    cout<< "Enter score 5: ";
    cin>> score05;
    
    //Calculations
    average= (score01+score02+score03+score04+score05)/5;
    
    cout<< setprecision(1)<<fixed;
    cout<< "The average score is: "<<average<< endl<<endl;
    
    system("pause");
    return 0;
}

