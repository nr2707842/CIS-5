/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 8:36 PM
 */

#include <iostream>
using namespace std;

/*Calculating number of widgets */
int main(int argc, char** argv) {

    float palletweight;
   float numwidgets=0;
    
   cout<<"Enter the pallet weight: ";cin>>palletweight;
   
   //Process input to output
   numwidgets=palletweight/9.2;
   
   //Display Outputs
   cout<<"The number of widgets on the pallet: "<<numwidgets<<endl;
   //Exit
   return 0;
}

