/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 8:44 PM
 */

#include <iostream>
#include<iomanip>
using namespace std;

/*Calculating the number of calories */
int main(int argc, char** argv) {
   //Initial variables
 int calperserv = 300, 
         servesize=3;
 //Declare variables
 double cookiesate, 
        calpercookie;
  //Map process Input to Outputs
 
calpercookie = (calperserv / servesize);

//output
cout << "How many cookies did you eat?" << endl;
cin >> cookiesate;
cout << "Calories Consumed: " << (cookiesate * calpercookie) << endl;
//Exit  
 return 0;
}

