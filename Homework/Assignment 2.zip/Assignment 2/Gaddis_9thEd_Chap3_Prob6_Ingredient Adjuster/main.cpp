/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 9:09 PM
 */


#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    //Initial varialbles
const double sugerpercookie = 1.5 / 48;
const double butterpercookie = 1.0 / 48;
const double flourpercookie= 2.75 / 48;
int amount;
  //Output
cout << setprecision(2) << fixed << showpoint << endl;
cout << "How many cookies would you like to make?" << endl;
cin >> amount;
  
cout << "You will need " << (sugerpercookie * amount) << " cups of sugar." << endl;
cout << "You will need " << (butterpercookie* amount) << " cups of butter." << endl;
cout << "You will need " << (flourpercookie * amount) << " cups of flour." << endl;

//Exit
return 0;
}
