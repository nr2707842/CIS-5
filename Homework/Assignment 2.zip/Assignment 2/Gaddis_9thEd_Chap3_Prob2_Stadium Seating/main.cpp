/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 9:19 PM
 */

#include <iostream>
#include<iomanip>

using namespace std;

/*Calculating amount of stadium seating*/
int main(int argc, char** argv) {
double classa = 15,
        classb = 12, 
        classc = 9;
double seta,
        setb,
        setc,
        totala, 
        totalb,
        totalc,
        total;
  
cout << setprecision(2) << fixed << showpoint << endl;
  
cout << "How many Class A tickets were sold?" << endl;
cin >> seta;
cout << "How many Class B tickets were sold?" << endl;
cin >> setb;
cout << "How many Class C tickets were sold?" << endl;
cin >> setc;
  
totala = seta * classa;
totalb = setb * classb;
totalc = setc * classc;
total = totala + totalb + totalc;
cout << "Income generated from ticket sales: $" << total << endl;
return 0;
}


