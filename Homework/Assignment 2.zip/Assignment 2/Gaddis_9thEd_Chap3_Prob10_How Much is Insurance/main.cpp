/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 8:55 PM
 */

#include <iostream>
#include<iomanip>
using namespace std;

/*Calculating price of insurance*/
int main(int argc, char** argv) {
   //Declare Variable
double replacementprice;
  //Output

cout << setprecision(2) << fixed  << showpoint << endl;
cout << " Enter replacement price of the building: $";
cin >> replacementprice;
cout << "Minimum amount of insurance : $" << (replacementprice * 0.80) << endl;
//Exit
return 0;
 }