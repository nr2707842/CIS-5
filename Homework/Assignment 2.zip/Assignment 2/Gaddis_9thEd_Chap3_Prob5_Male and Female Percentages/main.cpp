/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 18, 2018, 9:14 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;
int main() {
double females, 
        males, 
        percentfemale, 
        percentmale;
  
cout << "How many females are registered in a class?" << endl;
cin >> females;
cout << "How many males are registered in a class?" << endl;
cin >> males;

//Process input to output
percentfemale = (females / (males + females)) * 100;
percentmale = (males / (males + females)) * 100;
  
//output
cout << "Females: " << percentfemale << "%" << endl;
cout << "Males " << percentmale << "%" << endl;
//Exit
return 0;
}