/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 7:26 PM
 * Purpose: Celsius Tempurature Table
 */
//User Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//prototypes
double celsius(int);

//Execution Begins Here

int main()
{
    //Output to display table for conversion of F to C
	cout << "\nTable of Fahrenheit to Celsius temperatures 0 - 20\n"<<;
		 << "  Fahrenheit       Celsius\n"<<;
    //For loop to help calculate farnheit to celsius
	for (int F = 0; F <= 20; F++)
	{
		cout << "      " << setw(2) << F;
		cout << "          "
			 << setw(3) << celsius(F) << endl;
	}
	cout << endl;
	return 0;
}

double celsius(int F)
{
	//Exit here
	return (5.0 * (F - 32))/9;
}