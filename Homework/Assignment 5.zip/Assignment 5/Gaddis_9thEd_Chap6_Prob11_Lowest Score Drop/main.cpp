/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 9:13 PM
 * Purpose: Lowest Score Drop 
 */

#include <iostream>

using namespace std;

// Prototypes
void getScore(int &);
void calcAverage(int, int, int, int, int, int);
int findLowest(int, int, int, int, int, int);

//Declare Variables
//Execution Begins Here
int main() {
	int testScore1,
		testScore2,
		testScore3,
		testScore4,
		testScore5,
		testScore6;

//loop to get the score for the tests
	for (int i = 0; i < 6; i++){
		if (i == 0) {
			getScore(testScore1);
		}
		else if (i == 1) {
			getScore(testScore2);
		}
		else if (i == 2) {
			getScore(testScore3);
		}
		else if (i == 3) {
			getScore(testScore4);
		}
		else if (i == 4) {
			getScore(testScore5);
		}
		else if (i == 5) {
			getScore(testScore6);
		}
	} 
        
        //calculation for the average score of tests

	calcAverage(testScore1, testScore2, testScore3, testScore4, testScore5, testScore6);

	return 0;
}

//output to display the scores of test
void getScore(int &score) {
	int validScore;
	cout << "Enter test score: ";
	cin >> validScore;
	
        // in case of invalid score entry, ouput will display
	while ((validScore < 0) || (validScore > 100)) {
		cout << "Test scores can only be between 0 and 100." << endl
			<< "Reenter test score: ";
		cin >> validScore;
	}
	score = validScore;
}

void calcAverage(int score1, int score2, int score3, int score4, int score5, int score6) {

	int dropScore = findLowest(score1, score2, score3, score4, score5, score6);
	int sum = score1 + score2 + score3 + score4 + score5 + score6 - dropScore;
	double average = sum / 5.0;
//output to display the average score
	cout << "The average score is: " << average << endl;
}
//loop to find the lowest test score
int findLowest(int score1, int score2, int score3, int score4, int score5, int score6) {
	int lowestScore;
	if (score1 <= score2) {
		lowestScore = score1;
	}
	else {
		lowestScore = score2;
	}
	if (score3 < lowestScore) {
		lowestScore = score3;
	}
	if (score4 < lowestScore) {
		lowestScore = score4;
	}
	if (score5 < lowestScore) {
		lowestScore = score5;
	}
	if (score6 < lowestScore) {
		lowestScore = score6;
	}
	return lowestScore;
}
