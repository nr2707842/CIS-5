/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 8:03 PM
 * Purpose: Safest Driving Area
 */

//User Libraries
#include <iostream>
#include <cstdlib>

using namespace std;

//Prototypes
int getNumAccidents(int numA){
    cout << "Enter the number of accidents in this area.";
    cin >> numA;
    return numA;
}

//calculation to get the number of accidents
void findLowest(int north, int south, int east, int west, int center){
     int lowest;
     lowest = 0;
     lowest = south;
     if (lowest > north){
       lowest = north;}
        if (lowest > south){
         lowest = south;}
         if (lowest > east){
            lowest = east;}
            if (lowest > west){
              lowest = west;}
               if  (lowest > center){
                   lowest = center;} 
     
     
               //output to ask fot the number of accidents in different regions    
            if (lowest == north)          
               cout << "The area with the lowest number of accidents is the North\n\n";
            else if (lowest == south)
               cout << "The area with the lowest number of accidents is the South\n\n";
            else if (lowest == west)
               cout << "The area with the lowest number of accidents is the West\n\n";
            else if (lowest == east)
               cout << "The area with the lowest number of accidents is the East\n\n";
            else if (lowest == center)
               cout << "The area with the lowest number of accidents is the Center\n\n";
}
//output to provide the number of accidents
int main(){
   
int north, south, east, west, center;    
cout << "Enter the number of accidents in each sector,\n";
north = getNumAccidents(1);
south = getNumAccidents(2);
east = getNumAccidents(3);
west = getNumAccidents(4);
center = getNumAccidents(5);

//output to display the number of least accidents in each area
cout << "Accidents in North " << north << endl;
cout << "Accidents in South " << south << endl;
cout << "Accidents in East" << east << endl;
cout << "Accidents in West" << west << endl;
cout << "Accidents in Center" << center <<;
findLowest(north, south, east, west, center);
system("PAUSE");
//exit here
return 0;
}