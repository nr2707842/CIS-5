/* 
 * File:   main.cpp
 * Author: Nadia Rahbany    
 * Created on November 11, 2018, 7:08 PM
 * Purpose: Kinetic Energy
 */

//System Libraries
#include <iostream>//I/O Library -> cout,endl
#include <math.h>

using namespace std;
//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

float kineticEnergy(float m, float v);
//<ain Function
//Execution Begins Here
int main() 
{
//Using float variable for the kinetic energy values
  float ke;  //Kinetic energy 
  float m;  //Mass 
  float v;  //Velocity 

  cout << "Enter kg: ";
  cin >> m;
  cout << "Enter velocity in meters per second: ";
  cin >> v;
//output to display kinetic energy of object
  ke = kineticEnergy(m, v);
  cout << "Kinetic energy of object:" << ke << endl;

  
  return 0;
}
//Harness return
float kineticEnergy(float m, float v)
{
 // Exit here
  return (0.5 * m) * (pow(v,2));
}
