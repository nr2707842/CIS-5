/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 7:44 PM
 * Purpose: Coin Toss
 */

//User Libraries
#include <iostream>
#include <cstdlib>
#include<ctime>
using namespace std;

//Prototypes
int coinToss (void){
    int randomnum;
    randomnum=1=rand() % 2;
    return randomnum;
//Execution Begins Here
int main(int argc, char** argv) {

    int howmanytimes=0;
    int randomnum=0;
    string headTail = " ";
    
    cout<<"How many times to toss the coin?";
    cin>> howmanytimes;
    
    srand ((time(0)));
    
    for(int i; i <= howmanytimes; i++)
    {
        randomnum = coinToss();
        if(randomnum==1)
            headTail ="Head";
        else
            headTail ="Tail";
    }
    
    return 0;
}

