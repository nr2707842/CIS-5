/* 
 * File:   main.cpp
 * Author: Nadia
 * Created on November 11, 2018, 8:49 PM
 * Purpose: Present Value
 */

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

// Function prototypes
double presentValue(double, double, int);

//Execution Begins Here!!

//Declare Variables
int main()
{
	double pvalue,
		   fvalue,
		   airate;
	int    	  yrs;
//output to ask for the fvalue, airate, yrs
	cout << "\n              Present value calculator\n"
		 << "What is the amount you will have in the future? ";
	cin  >> fvalue;
	cout << "What is the annual interest rate? ";
	cin  >> airate;
	cout << "How long will you leave the money in the account? ";
	cin  >> yrs;

	pvalue = presentValue(fvalue, airate, yrs);
//output to display the number to have in the acount and the and the balance in the number of years
	cout << fixed << showpoint << setprecision(2);
	cout << "You must deposit $" << PValue << " to have  $"
		 << fvalue << " in " << yrs << " years.\n\n";

	return 0;
}

double presentValue(double fvalue, double airate, int yrs)
{
	return fvalue / pow(1 + airate, yrs);
}