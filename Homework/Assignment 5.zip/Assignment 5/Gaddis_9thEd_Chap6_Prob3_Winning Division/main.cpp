/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 8:21 PM
 * Purpose: Winning Division
 */

#include <iostream>

using namespace std;
//Prototypes
double getsales (double &);
void findhighest (double, double, double, double);

//Execution Begins here
int main(int argc, char *argv[])
{
    //Declare variables
    double northeast = 0;
    double southeast = 0;
    double northwest = 0;
    double southwest = 0;
    
    //output to ask for the number of sales
    cout << "Enter NorthEast sales: $" ;
    cout << getsales(northeast) << endl;
    cout << "Enter SouthEast sales: $"; 
    cout << getsales(southeast) << endl;
    cout << "Enter NorthWest sales: $";
    cout << getsales(northwest) << endl;
    cout << "Enter SouthWest sales: $";
    cout << getsales(southwest) << endl;
    
    findhighest(northeast, southeast, northwest, southwest);
    
    return 0;
}

double getsales (double & num)
{
    do
    {
        if(!cin)
        {
            cin.clear();
            cin.ignore(100, '\n');
        }
        
                cin >> num;

        
        
    }while(!cin || num <= 0);
    return num;
}

void findhighest (double ne, double se, double nw, double sw) 
{
    //output to display WHO has the highest sales
    const char *who = "Northeast";
    double high = ne;
    if(se > high)
    {
        who = "Southeast";
        high = se;
    }
    if(nw > high)
    {
        who = "Northwest ";
        high = nw;
    }
    if(sw > high)
    {
        who = "Southwest ";
        high = sw;
    }
        
    cout << who << "has the highest sale $ " << high<< endl;
}
