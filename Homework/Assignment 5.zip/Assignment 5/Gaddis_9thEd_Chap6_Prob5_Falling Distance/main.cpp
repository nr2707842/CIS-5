/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 6:40 PM
 * Purpose: Falling Distance
 */

//System Libraries
# include <iostream>
# include <cmath>
# include <string>
using namespace std;
//Declare variables

void fallingDistance2(double &, double);
double fallingDistance1(double);
const double g = 9.8;
double t;
double d;
int main()

//output to display paassby values
{
    cout<<"PASSBY VALUES.\n";
    cout<<"TIME \t DISTANCE\n";
    //for loop to determine d and t value
    for (t=1;t<=10;t++)
    {
        cout<<t<<"\t\t"<<fallingDistance1(t)<<endl;
    }
    
    //output to display reference values
    cout<<"REFERENCE VALUES.\n";
    cout<<"TIME \t DISTANCE\n";
    
    //for loop to calculate the t values and making the chart for distance and time
    for (t=1;t<=10;t++)
    {
        fallingDistance2(d, t);
        cout<<t<<"\t\t"<<d<<endl;
    }
    return 0;
}
//harnessing return value in loop
double fallingDistance1(double t)
{
    return 0.5*9.8*t*t;
}
void fallingDistance2(double &refd, double t)
{
    refd=0.5*9.8*t*t;
}
