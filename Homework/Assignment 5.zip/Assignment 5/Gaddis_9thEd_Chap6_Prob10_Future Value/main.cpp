/* 
 * File:   main.cpp
 * Author: Nadia
 * Created on November 11, 2018, 9:00 PM\
 * Purpose: Future Value
 */

#include <iostream>
#include <cmath>
using namespace std;
//prototypes
double futureValue(double value, double rate, int num_month){ return value * pow(1 + rate / 100, num_month); }
//Main Function
//Execution Begins Here
//Declare Variables
int main() {
double P, i;// p for present value, i for interest
int t;//t for the number of months
cout << "Input your present value, monthly interest rate and number of months :";
cin >> P >> i >> t;

//output to display the value for future
cout << "Your future value is: " << futureValue(P, i, t) << endl;

//exit here
return 0;
}
