/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on November 11, 2018, 8:35 PM
 * Purpose: Markup
 */

//User Libraries
#include <iostream>
#include <iomanip>

using namespace std;

// Prototypes
double calculatedRetail (double cost, double markUp);

int main()
{
double retail, cost, markUp;	

cout<<fixed<<showpoint<<setprecision(2);	

//ouptut to ask for the wholesale cost
cout<<"Enter the wholesale cost: $";
cin >>cost;
//calculation to validate cost
while (cost<0)
{
cout<<"Enter a positive Number. $"<<endl;
cin >>cost;
}

cout<<"Enter the markup percentage: ";
cin >>markUp;
//calculation to validate the percentage	
while (markUp<0)
{
cout<<"Enter a positive number for markup: ";
cin >>markUp;
}
//calculation to convert markup
markUp = (markUp/100);

//output to display the markup price

cout<<"The retail price for this item is: "<<endl;
cout<<"$ " <<calculatedRetail(cost, markUp)<<endl;

return 0;
}
double calculatedRetail (double cost, double markUp)
{
    //exit, return calculates the retail price
return (cost*markUp)+cost; 
}