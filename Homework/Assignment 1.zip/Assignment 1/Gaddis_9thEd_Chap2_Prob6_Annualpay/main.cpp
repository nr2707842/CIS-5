/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 11, 2018, 7:47 PM
 */

#include <iostream>

using namespace std;

/* Cost of Total Annual Pay*/
int main(int argc, char** argv) {
    
    int payAmount;
    int payPeriods;
    int annualPay;
    
    payAmount= 2200.0,
    payPeriods= 26;
    annualPay= payAmount*payPeriods;
    
        cout << "Annual Pay Total: $" << annualPay << endl;

    
    return 0;
}

