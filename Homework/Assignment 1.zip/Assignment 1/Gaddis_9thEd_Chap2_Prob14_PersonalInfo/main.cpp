/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 11, 2018, 8:28 PM
 */

#include <iostream>

using namespace std;

/*Personal Info*/
int main(int argc, char** argv) {

    cout<<"Name: Nadia Rahbany"<<endl
    <<"Address: 1181 California Ave,Corona,CA,92881 "<<endl
            <<"Telephone Number: 888-214-2134"<<endl
            <<"Collge Major: Computer Information Systems"<<endl;
            
            
    return 0;
}

