/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 11, 2018, 8:39 PM
 */

#include <iostream>

using namespace std;

/* Calculating Miles per Gallon*/
int main(int argc, char** argv) {

    int tanklimit;
    int mpt;
    int totalmpt;
    tanklimit=15;
    mpt=375;
    totalmpt=375/15;
    
    cout<<"Number of miles per gallon: "<< totalmpt<<endl;
    return 0;
}

