/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 *
 * Created on September 11, 2018, 8:22 PM
 */

#include <iostream>

using namespace std;

/* Predicting the Sales Total*/
int main(int argc, char** argv) {
 
    double salesdivision(0.58);
    int totalsales= 8600000;
    int sales= salesdivision*totalsales;
    
     cout << "Company Annual Sales:" <<" $" <<totalsales << endl;
     cout <<"The East Coast Sales Total:" << " $" <<sales << endl;
    
    return 0;
}

