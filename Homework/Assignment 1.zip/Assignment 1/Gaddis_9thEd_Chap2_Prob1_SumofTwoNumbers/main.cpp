/* 
 * File:   main.cpp
 * Author: Nadia Rahbany
 * Created on September 11, 2018, 7:24 PM
 */

#include <iostream>
using namespace std;

/* Sum of variables 50 and 100 */
int main(int argc, char** argv) {

    int a;
    int b;
    int total;
    
    a=50;
    b=100;
    total= a+b;
    
        cout << "The sum is: " << total << endl;
    return 0;
}

