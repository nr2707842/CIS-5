/* 
 * File:   main.cpp
 * Author: Nadia
 * Created on September 11, 2018, 7:59 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

/* Finding the total Purchase Cost*/
int main(int argc, char** argv) {

    double Item1(15.95),
            Item2(24.95),
            Item3(6.95),
            Item4(12.95),
            Item5(3.95),
            Subtotal(Item1+Item2+Item3+Item4+Item5),
            SalesTax(Subtotal*0.7),
            Total(Subtotal+SalesTax);
        
    cout <<"Item 1: " <<" $" <<Item1 << endl;
    cout <<"Item 2: " <<" $" <<Item2 << endl;
    cout <<"Item 3: " <<" $" <<Item3 << endl;
    cout <<"Item 4: " <<" $" <<Item4 << endl;
    cout <<"Item 5: " <<" $" <<Item5 << endl;
    cout <<"Subtotal: " <<" $" <<Subtotal << endl;
    cout <<"SalesTax: " <<" $" <<SalesTax << endl;
    cout <<"Total: " << " $" <<Total << endl;

    return 0;
}

